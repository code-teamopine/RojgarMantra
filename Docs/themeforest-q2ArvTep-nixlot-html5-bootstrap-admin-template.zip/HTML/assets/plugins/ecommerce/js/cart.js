$(document).ready(function () {
	$('#cart').simpleCart();
});